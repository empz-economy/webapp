from nacl.signing import SigningKey
import base64
import hashlib
import multiprocessing
import time
import re

user_suffix = input(
    "Please enter any additional characters for your domain prefix after 'empz' (or '0' for none)."
).lower()

if user_suffix == "0":
    user_suffix = ""
elif not re.fullmatch(r"[a-z2-7]*", user_suffix):
    print("Invalid input. Please try again using only characters a-z and 2-7.")
    exit(1)

prefix = ("empz" + user_suffix).encode()

def generate():
    while True:
        signing_key = SigningKey.generate()
        private_key = signing_key.encode()
        public_key = signing_key.verify_key.encode()

        checksum = hashlib.sha3_256(b".onion checksum" + public_key + b"\x03").digest()[:2]
        onion_address_bytes = public_key + checksum + b"\x03"
        onion = base64.b32encode(onion_address_bytes).lower().rstrip(b"=") + b".onion"

        if onion.startswith(prefix):
            return private_key, onion.decode()
        time.sleep(0.01) # Sleeps for 10ms after each attempt to avoid excessive CPU strain.

def worker(queue):
    pk, onion = generate()
    queue.put((pk, onion))

if __name__ == "__main__":
    manager = multiprocessing.Manager()
    q = manager.Queue()
    processes = []

    for _ in range(multiprocessing.cpu_count()):
        p = multiprocessing.Process(target=worker, args=(q,))
        p.start()
        processes.append(p)

    private_key, onion = q.get()

    for p in processes:
        p.terminate()

    with open("hs_ed25519_key.bi", "wb") as f:
        f.write(private_key)
    with open("base64.txt", "w") as f:
        f.write(base64.b64encode(private_key).decode())
    with open("domain.txt", "w") as f:
        f.write(onion)

    print(f"Your vanity onion domain has been successfully generated. Check out the folder you installed for the generated files.")
    print("Please remember to back up your private key securely. Thank you for supporting Empz Economy.")